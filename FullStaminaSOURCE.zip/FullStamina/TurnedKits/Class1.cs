﻿using Rocket.API;
using Rocket.Core.Plugins;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Player;
using SDG.Unturned;
using Steamworks;
using System.Collections.Generic;
using UnityEngine;

namespace SkyPlugin
{
    public class SkyPlugin : RocketPlugin
    {
        public static SkyPlugin Instance;

        protected override void Load()
        {
            Instance = this;
            Rocket.Core.Logging.Logger.Log("SkyPlugin yüklendi!");
        }

        protected override void Unload()
        {
            Rocket.Core.Logging.Logger.Log("SkyPlugin kaldırıldı!");
        }
    }

    public class CommandSky : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;
        public string Name => "sky";
        public string Help => "950 yüksekliğinde metal roof oluşturur ve üzerine ışınlar.";
        public string Syntax => "/sky";
        public List<string> Aliases => new List<string>();
        public List<string> Permissions => new List<string> { "sky" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;

            const ushort metalRoofId = 373;
            const float targetHeight = 950f;
            const float teleportOffset = 2f;

            Vector3 playerPos = player.Position;
            Vector3 structurePos = new Vector3(playerPos.x, targetHeight, playerPos.z);

            Asset foundAsset = Assets.find(EAssetType.ITEM, metalRoofId);

            if (foundAsset == null)
            {
                UnturnedChat.Say(player, "Hata: Metal roof (373) asseti bulunamadı.", Color.red);
                return;
            }

            ItemStructureAsset asset = foundAsset as ItemStructureAsset;
            if (asset == null)
            {
                UnturnedChat.Say(player, $"Hata: 373 ID'li asset bir structure değil (tip: {foundAsset.GetType().Name}).", Color.red);
                return;
            }

            // İkinci parametre dayanıklılık (health) - asset.health kullanıyoruz
            Structure structure = new Structure(asset, asset.health);

            bool placed = StructureManager.dropStructure(
                structure,
                structurePos,
                0f,
                0f,
                0f,
                0,
                CSteamID.Nil.m_SteamID
            );

            if (!placed)
            {
                UnturnedChat.Say(player, "Hata: Yapı yerleştirilemedi.", Color.red);
                return;
            }

            Vector3 teleportPos = new Vector3(structurePos.x, structurePos.y + teleportOffset, structurePos.z);
            player.Teleport(teleportPos, player.Rotation);

            UnturnedChat.Say(player, "Metal roof 950 yüksekliğine oluşturuldu, üzerine ışınlandın!", Color.green);
        }
    }
}