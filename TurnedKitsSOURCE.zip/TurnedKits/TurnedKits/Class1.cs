﻿using System;
using System.Collections.Generic;
using Rocket.API;
using Rocket.Core.Plugins;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Player;
using SDG.Unturned;
using UnityEngine;

namespace Kits
{
    // Kit Modeli
    public class Kit
    {
        public string Name { get; set; }
        public List<ushort> Items { get; set; }
        public int CooldownSeconds { get; set; }
        public string Permission { get; set; }
        public bool IsVehicle { get; set; }
        public ushort VehicleId { get; set; }
    }

    // Ana Eklenti Sınıfı
    public class KitPlugin : RocketPlugin
    {
        public static List<Kit> KitsList = new List<Kit>();
        public static Dictionary<string, DateTime> Cooldowns = new Dictionary<string, DateTime>();

        protected override void Load()
        {
            KitsList.Add(new Kit { Name = "emek", Permission = "kit.emek", CooldownSeconds = 7200, Items = new List<ushort> { 2, 3, 81, 81, 16, 394, 394, 394, 394, 394 } });
            KitsList.Add(new Kit { Name = "saglik", Permission = "kit.saglik", CooldownSeconds = 3600, Items = new List<ushort> { 394, 394, 394, 394, 394, 394, 394, 394, 394, 394 } });
            KitsList.Add(new Kit { Name = "bonus", Permission = "kit.bonus", CooldownSeconds = 7200, Items = new List<ushort> { 288, 4, 6, 6, 6, 6, 394, 394, 394, 394 } });
            KitsList.Add(new Kit { Name = "asker", Permission = "kit.asker", CooldownSeconds = 7200, Items = new List<ushort> { 1037, 307, 308, 309, 310, 334, 17, 17, 149, 22, 1007, 395, 395, 395, 395, 395, 395, 8} });
            KitsList.Add(new Kit { Name = "ozelteam", Permission = "kit.ozelteam", CooldownSeconds = 10800, Items = new List<ushort> { 1169, 1170, 1171, 1172, 1525, 334, 17, 17, 17, 17, 17, 363, 22, 1007, 395, 395, 395, 395, 395, 395, 8, 149 } });
            KitsList.Add(new Kit { Name = "raid", Permission = "kit.raid", CooldownSeconds = 86400, Items = new List<ushort> { 132, 133, 133, 133, 1241, 1241, 1241, 1241, 1241, 1240 } });
            KitsList.Add(new Kit { Name = "apc", Permission = "kit.apc", CooldownSeconds = 86400, IsVehicle = true, VehicleId = 53, Items = new List<ushort>() });
            KitsList.Add(new Kit { Name = "heli", Permission = "kit.heli", CooldownSeconds = 86400, IsVehicle = true, VehicleId = 93, Items = new List<ushort>() });

            // Logger çakışması bu şekilde çözüldü
            Rocket.Core.Logging.Logger.Log("Gelişmiş Kit Eklentisi Başarıyla Yüklendi!", ConsoleColor.Green);
        }

        protected override void Unload()
        {
            Rocket.Core.Logging.Logger.Log("Kit Eklentisi Devre Dışı.", ConsoleColor.Yellow);
        }
    }

    // /kit Komutu
    public class CommandKit : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;
        public string Name => "kit";
        public string Help => "Belirtilen kiti almanızı sağlar.";
        public string Syntax => "/kit <kitAdı>";
        public List<string> Aliases => new List<string>();
        public List<string> Permissions => new List<string> { "kit" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            if (command.Length < 1) { UnturnedChat.Say(player, "Kullanım: /kit <kitAdı>", Color.yellow); return; }

            string inputKit = command[0].ToLower();
            Kit kit = KitPlugin.KitsList.Find(k => k.Name == inputKit);

            if (kit == null) { UnturnedChat.Say(player, "Böyle bir kit bulunamadı!", Color.red); return; }
            if (!player.HasPermission(kit.Permission)) { UnturnedChat.Say(player, "Gerekli yetkiniz yok!", Color.red); return; }

            string key = player.CSteamID.m_SteamID + "_" + kit.Name;
            if (KitPlugin.Cooldowns.TryGetValue(key, out var nextUse) && DateTime.Now < nextUse)
            {
                TimeSpan ts = nextUse - DateTime.Now;
                UnturnedChat.Say(player, $"Bekleme süresi: {ts.Hours}s {ts.Minutes}d {ts.Seconds}s", Color.red);
                return;
            }

            if (kit.IsVehicle)
            {
                // Araç spawn noktası: Oyuncunun önü + dikeyde yukarı taşıma
                // Tüm araçlar için 2 birim yukarıda spawn ederek yere gömülmeyi engelliyoruz
                Vector3 spawnPos = player.Position + (player.Player.transform.forward * 4f) + (Vector3.up * 2f);

                VehicleManager.spawnVehicleV2(kit.VehicleId, spawnPos, player.Player.transform.rotation);
                UnturnedChat.Say(player, kit.Name.ToUpper() + " başarıyla spawn edildi!", Color.green);
            }
            else
            {
                foreach (ushort item in kit.Items) player.GiveItem(item, 1);
                UnturnedChat.Say(player, kit.Name.ToUpper() + " envanterinize eklendi!", Color.green);
            }
            KitPlugin.Cooldowns[key] = DateTime.Now.AddSeconds(kit.CooldownSeconds);
        }
    }

    // /kits Komutu
    public class CommandKits : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;
        public string Name => "kits";
        public string Help => "Sahip olduğunuz kitleri listeler.";
        public string Syntax => "/kits";
        public List<string> Aliases => new List<string>();
        public List<string> Permissions => new List<string> { "kit" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            List<string> list = new List<string>();
            foreach (Kit kit in KitPlugin.KitsList)
                if (player.HasPermission(kit.Permission))
                    list.Add(char.ToUpper(kit.Name[0]) + kit.Name.Substring(1));

            if (list.Count > 0)
                UnturnedChat.Say(player, string.Join(", ", list) + " kitlerine sahipsin!", Color.cyan);
            else
                UnturnedChat.Say(player, "Erişim izniniz olan kit yok!", Color.red);
        }
    }
}